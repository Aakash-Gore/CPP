#include<iostream>
#include<cmath>

using namespace std;


struct Transaction
{
int user_id;

bool is_deposit;

int amount, balance;
void print()
{
if(is_deposit)
 cout<<user_id<<" "<<"deposit"<<" "<<amount<<" "<<balance<<endl;

 else
 cout<<user_id<<" "<<"withdraw"<<" "<<amount<<" "<<balance<<endl;
}
};
////////////////////////
struct User
{
int id;

int balance;

int n_deposits=0, n_withdrawals=0;
Transaction t[5];
int call=0;

int deposit(int amount)
{
balance+=amount;
n_deposits++;
t[call]={id,1,amount,balance};
call++;
return 0;
}
int withdraw(int amount)
{
if(amount>balance)
return -1;
else
{
 balance-=amount;
 n_withdrawals++;
 t[call]={id,0,amount,balance};
 call++;
 return 0;
}
}
void print_history()
{
}
};
////////////////
struct Request
{
int user_id;

bool is_deposit;

int amount;
void print()
{

}
};
///////////////////////////////////
struct Bank
{
int n_users;
int i=0;
int j=0;

User users[10];

int n_reqs;
Request reqs[10];

int add_user(int init_bal)
{
if(i>9)
return -1;
users[i].id=i;
users[i].balance=init_bal;
i++;
n_users=i;

return 0;


}


void add_request(int user_id, bool is_deposit, int amount)
{
 reqs[j].user_id=user_id;
 reqs[j].is_deposit=is_deposit;
 reqs[j].amount=amount;
 j++;
 n_reqs=j;
}
int get_balance(int user_id)
{
return users[user_id].balance;
}
int get_num_deposits(int user_id)
{
return users[user_id].n_deposits;
}
int get_num_withdrawals(int user_id)
{
return users[user_id].n_withdrawals;
}
void deposit(int user_id, int amount)
{
users[user_id].deposit(amount);

}
void withdraw(int user_id, int amount)
{
 users[user_id].withdraw(amount);
}
void print_user_history(int user_id)
{
int a=users[user_id].call-1;
while(a>=users[user_id].call-3 && a>=0)
{
 users[user_id].t[a].print();
 a--;
}
}
};
